import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler, ContextTypes

TOKEN = "8149460454:AAGkOO3sqj14wjw2D3ECSY6zXOzAmUuOARs"
ADMIN_ID = 958991991

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# Команда старт
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [[InlineKeyboardButton("Создать вакансию", callback_data="create_job"),
                 InlineKeyboardButton("Создать анкету", callback_data="create_cv")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Привет! 👋 Выберите действие:", reply_markup=reply_markup)

# Обработка кнопок
async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data == "create_job":
        await query.edit_message_text("✍️ Отправьте описание вакансии:")
    elif query.data == "create_cv":
        await query.edit_message_text("📝 Отправьте вашу анкету:")

# Получение текста от пользователя
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_text = update.message.text
    keyboard = [[InlineKeyboardButton("Откликнуться", url=f"tg://user?id={update.message.from_user.id}")]]
    reply_markup = InlineKeyboardMarkup(keyboard)

    message = f"📌 Новая публикация:

{user_text}

Связаться: @{update.message.from_user.username}"

    # Отправляем в канал
    channel_id = "@rabotavbishkeke01"
    await context.bot.send_message(chat_id=channel_id, text=message, reply_markup=reply_markup)

    # Уведомление админу
    if update.message.from_user.id != ADMIN_ID:
        await context.bot.send_message(chat_id=ADMIN_ID, text=f"👤 Пользователь @{update.message.from_user.username} отправил пост.")

def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    app.run_polling()

if __name__ == "__main__":
    main()
